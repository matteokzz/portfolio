gsap.registerPlugin(ScrollTrigger, SplitText)

const el = document.querySelector('#text')
const btn = document.querySelector('#replay')

let split
let tween

function play() {
	tween?.kill()
	split?.revert()

	split = new SplitText(el, {
		type: 'chars',
		charsClass: 'split-char',
	})

	tween = gsap.fromTo(
		split.chars,
		{ opacity: 0, y: 40 },
		{
			opacity: 1,
			y: 0,
			duration: 1.25,
			ease: 'power3.out',
			stagger: 0.05,
		},
	)
}

play()

btn.addEventListener('click', play)
